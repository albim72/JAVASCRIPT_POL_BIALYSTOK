import { Component } from '@angular/core';
import { FormGroup, FormControl } from "@angular/forms";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Projekt Angular CLi';
  //todaydate;
  //componentproperty;
  //emailid;
  //formdata;
  // @ts-ignore
  formdata: FormGroup;

  ngOnInit(){
    this.formdata = new FormGroup({
      emailid: new FormControl('mojangular@firma.pl'),
      passwd: new FormControl('abcd1234')
    });
  }
  onClickSubmit(data: { emailid: string; }){
    alert('Wprowadzono e-mail id: '+ data.emailid);
  }
}
