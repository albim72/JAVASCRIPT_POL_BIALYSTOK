import {Injectable} from '@angular/core';
import {Todo} from './todo';
import {TodoStatus} from './todo-status.enum';

@Injectable()
export class TodosService {
  getTodos(): Todo[] {
    return [
      { name: 'Zadanie 1', status: TodoStatus.BUG},
      { name: 'Zadanie 2', status: TodoStatus.TODO},
      { name: 'Zadanie 3', status: TodoStatus.IN_REVIEW}
    ];
  }
}
