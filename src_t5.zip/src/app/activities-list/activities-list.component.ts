import {Component,OnInit} from "@angular/core";

@Component({
  selector: 'app-activities-list',
  templateUrl: './activities-list.component.html',
  styleUrls: ['./activities-list.component.css']
})

export class ActivitiesListComponent implements OnInit{
  constructor() {
  }
  ngOnInit() {
  }
}
