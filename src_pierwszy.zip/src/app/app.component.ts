import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Projekt Angular CLi';
  //todaydate;
  //componentproperty;
  ngOnInit(){}
  onClickSubmit(data: { emailid: string; }){
    alert('Wprowadzono e-mail id: '+ data.emailid);
  }
}
