// JavaScript Document
var janKot = {
  age: 52,
  occupations: ["pisarz", "reżyser", "producent", "kompozytor", "aktor"],
  shows: [
    {
      title: "Burza",
      femaleLead: true,
      characters: [
        { name: "Ela", role: "policjantka" },
        { name: "Alan", role: "szalony naukowiec" }
      ]
    },
    {
      title: "Dr.Oprawca",
      characters: [
        { name: "Adam", role: "szalony naukowiec" },
        { name: "Ola", role: "asystentka" }
      ]
    },
    {
      title: "Noc wampirów",
      femaleLead: true,
      characters: [
        { name: "Lora", role: "wampir" },
        { name: "Kowalski", role: "pogromca" }
      ]
    },
    {
      title: "Długi lot",
      characters: [
        { name: "Marek", role: "kapitan" },
        { name: "Olaf", role: "machanik" }
      ]
    }
  ]
}