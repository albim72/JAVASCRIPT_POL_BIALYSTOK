export class ConfigService {

}
