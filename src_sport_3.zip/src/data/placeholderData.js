export const data = {
  categories: ["Sporty wodne","Piłka nożna","Szachy","Bieganie"],
  products: [
    {id:1, name:"Kajak",category:"Sporty wodne",
      description:"jednoosobowa łódka", price:1230},
    {id:2, name:"Kamizelka ratunkowa",category:"Sporty wodne",
      description:"Bezpieczeństwo", price:171},
    {id:3, name:"Czepek pływacki",category:"Sporty wodne",
      description:"ochrona włosów", price:63},
    {id:4, name:"Piłka Adidas",category:"Piłka nożna",
      description:"piłka z nadrukiem", price:55},
    {id:5, name:"koszulka DDD",category:"Piłka nożna",
      description:"koszulka techniczna", price:112},
    {id:6, name:"gwizdek",category:"Piłka nożna",
      description:"konieczny dla sędziego", price:33},
    {id:7, name:"Zestaw szachów",category:"Szachy",
      description:"podstawa dla szachisty", price:150},
    {id:8, name:"Czapka geniusza",category:"Szachy",
      description:"usprawnia myślenie", price:250},
    {id:9, name:"Krzywe krzesło",category:"Szachy",
      description:"rozprasza przeciwnika", price:333},
    {id:10, name:"Buty trailowe",category:"Bieganie",
      description:"buty w teren", price:670},
    {id:11, name:"opaska elastyczna",category:"Bieganie",
      description:"pomoc w nagłych prrzypadkach", price:16},
    {id:12, name:"kije górskie",category:"Bieganie",
      description:"wsparcie w biegach górskich", price:290}
  ]
}
