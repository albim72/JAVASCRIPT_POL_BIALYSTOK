import {Component,OnInit} from "@angular/core";
import {StockService, StockInteface} from "../../services/stocks.service";

@Component({
  selector: 'dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})

export class DashboardComponent implements OnInit{
  stocks: Array<StockInteface>;
  symbols:Array<string>;

  constructor(private service:StockService) {
    this.symbols = service.get();
  }
  ngOnInit() {
    this.service.load(this.symbols).subscribe(stocks => this.stocks = stocks);
  }
}
