import {TestBed,async,inject} from '@angular/core/testing';
import { StockService } from './stocks.service';
import {serialize} from "v8";


describe('Service', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        StockService
      ]
    });
  });

  it('should create', inject([StockService],(service:StockService)=>
  {
    expect(service).toBeTruthy();
  }));
  });
